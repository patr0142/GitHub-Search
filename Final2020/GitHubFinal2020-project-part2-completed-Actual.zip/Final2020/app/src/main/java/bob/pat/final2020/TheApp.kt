package bob.pat.final2020

import android.app.Application
import android.content.Context

/*
 * Created by Tony Davidson on October 24, 2020
 *
 *  Note this is the app (Android Assignment 2) after all classes
 *
*/

class TheApp : Application() {

    override fun onCreate() {
        super.onCreate()
        context = applicationContext
    }

    companion object {
        lateinit var context: Context
            private set
    }
}